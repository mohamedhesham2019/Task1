const num = parseInt(prompt("Please Enter a number:"));
let factorial = 1;

if (num < 0) {
  console.log("Error!");
}
 else 
 {
  for (let i = 1; i <= num; i++) 
  {
    factorial *= i;
  }
  console.log(`The factorial of ${num} is: ${factorial}`);
}
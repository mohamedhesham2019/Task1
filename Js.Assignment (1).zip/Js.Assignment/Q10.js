function printRightAngleTriangle(rows) 
{
    for (let i = 1; i <= rows; i++) 
    {
      let pattern = '';
      for (let j = 1; j <= i; j++) 
      {
        pattern += '* ';
      }
      console.log(pattern);
    }
  }
  
  const rows = 5;
  printRightAngleTriangle(rows);
function isMultipleOf5Or8(num) 
{
    if (num % 5 === 0) {
      return true; 
    } else if (num % 8 === 0) {
      return true; 
    } else {
      return false; 
    }
  }
 
  console.log(isMultipleOf5Or8(10)); //TRUE
  console.log(isMultipleOf5Or8(16)); //TRUE
  console.log(isMultipleOf5Or8(23)); //FALSE
function Find50(n1, n2) 
{
  return ((n1 == 50 || n2 == 50) || (n1 + n2 == 50));
}
console.log(Find50(50, 50))
console.log(Find50(20, 30))
console.log(Find50(20, 20))
console.log(Find50(20, 50))


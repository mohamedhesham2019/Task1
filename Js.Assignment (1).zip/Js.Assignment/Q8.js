function findLargest(a, b, c) {
    let largest = a;
  
    if (b > largest) {
      largest = b;
    }
  
    if (c > largest) {
      largest = c;
    }
  
    return largest;
  }

  console.log(findLargest(10, 20, 30)); // 30 
  console.log(findLargest(-5, 0, 5)); // 5 
  console.log(findLargest(5, 5, 5)); // 5 (all numbers are the same)
function add(a, b) 
{
    return a + b;
  }
  
  function subtract(a, b)
   {
    return a - b;
  }
  
  function multiply(a, b) 
  {
    return a * b;
  }
  
  function divide(a, b)
   {
    if (b === 0) {
      return "Cannot divide by zero!";
    }
    return a / b;
  }

  const n1 = 10;
  const n2 = 5; 
  console.log(`Sum: ${add(n1, n2)}`);
  console.log(`Difference: ${subtract(n1, n2)}`);
  console.log(`Product: ${multiply(n1, n2)}`);
  console.log(`Quotient: ${divide(n1, n2)}`);
function checkNumberPositiveOrNegative(number) 
{
    if (number > 0) {
      return "Positive";
    } else if (number < 0) 
    {
      return "Negative";
    } 
    else 
    {
      return "Zero";
    }
  }
  const num = -5;
  const result = checkNumberPositiveOrNegative(num);
  console.log(`The number ${num} is ${result}.`);
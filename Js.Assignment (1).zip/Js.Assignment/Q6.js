function pos_neg(n1, n2)
{
  if ((n1 < 0 && n2 > 0) || n1 > 0 && n2 < 0) 
  {
    return true;
  }
  else 
  {
    return false;
  }
}
console.log(pos_neg(2, 2));
console.log(pos_neg(-2, 2));
console.log(pos_neg(2, -2));
console.log(pos_neg(-2, -2));

function storeAndPrintArray() {
    const array = [];
    const numberOfElements = 10; 
  
    for (let i = 0; i < numberOfElements; i++) {
      const element = parseInt(prompt(`Enter element - ${i}:`));
      array.push(element);
    }
  
    console.log("The elements in the array are:");
    array.forEach((element, index) => {
      console.log(`element - ${index}: ${element}`);
    });
  }
  
  storeAndPrintArray();
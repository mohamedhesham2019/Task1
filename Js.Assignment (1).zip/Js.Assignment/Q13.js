function sumOfTwoNumbers(a, b) 
{
    return a + b;
}
  
  const n1 = 3;
  const n2 = 10;
  const sum = sumOfTwoNumbers(n1, n2);
  console.log(`The sum of ${n1} and ${n2} is: ${sum}`);